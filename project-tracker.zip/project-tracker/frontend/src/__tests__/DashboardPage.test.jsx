import { render, screen } from '@testing-library/react';
import DashboardPage from '../DashboardPage';

// Mock the api module
jest.mock('../api', () => ({
  login: jest.fn(),
  getSubmissions: jest.fn()
}));

test('renders admin login form when not logged in', () => {
  render(<DashboardPage isLoggedIn={false} />);
  const loginTitle = screen.getByText(/Admin Login/i);
  expect(loginTitle).toBeInTheDocument();
});

test('renders dashboard when logged in', () => {
  render(<DashboardPage isLoggedIn={true} />);
  const dashboardTitle = screen.getByText(/Submission Dashboard/i);
  expect(dashboardTitle).toBeInTheDocument();
});

test('renders login and password fields', () => {
  render(<DashboardPage isLoggedIn={false} />);
  
  const usernameLabel = screen.getByText(/Username/i);
  expect(usernameLabel).toBeInTheDocument();
  
  const passwordLabel = screen.getByText(/Password/i);
  expect(passwordLabel).toBeInTheDocument();
});

test('renders search and filter components', () => {
  render(<DashboardPage isLoggedIn={true} />);
  
  const searchInput = screen.getByPlaceholderText(/Search by Lumen Name or AI Used/i);
  expect(searchInput).toBeInTheDocument();
});

test('renders table headers', () => {
  render(<DashboardPage isLoggedIn={true} />);
  
  const headers = ['Lumen Name', 'AI Used', 'Reward Amount', 'Timestamp', 'Screenshot'];
  headers.forEach(header => {
    const headerElement = screen.getByText(header);
    expect(headerElement).toBeInTheDocument();
  });
});